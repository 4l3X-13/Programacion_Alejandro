package Ejercicio1;

enum Estilo {
    tapaDura, tapaBlanda, deBolsillo
}

public class Libro {
    private String isbn;
    private String nombre;
    private String autor;
    public int numPag;
    public String genero;
    public Estilo formato;

    public Libro(String isbn, String nombre, String autor, int numPag, String genero, Estilo formato) {
        this.isbn = isbn;
        this.nombre = nombre;
        this.autor = autor;
        this.numPag = numPag;
        this.genero = genero;
        this.formato = Estilo.tapaDura;
    }


    public String getIsbn() {
        return isbn;
    }

    private void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public String getNombre() {
        return nombre;
    }

    private void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getAutor() {
        return autor;
    }

    private void setAutor(String autor) {
        this.autor = autor;
    }

    public int getNumPag() {
        return numPag;
    }

    public void setNumPag(int numPag) {
        this.numPag = numPag;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public Estilo getFormato() {
        return formato;
    }

    public void setFormato(Estilo formato) {
        this.formato = formato;
    }

    public int peso(Estilo formato, int numPag) {
        int pesoLibro;
        if (formato == Estilo.deBolsillo) {
            int pesoHojasBolsillo = numPag;
            int pesoTapaBolsillo = 10;
            pesoLibro = pesoHojasBolsillo + pesoTapaBolsillo;
            return pesoLibro;
        } else {
            int pesoHojasEst = numPag * 2;
            if (formato == Estilo.tapaDura) {
                int pesoTapaDura = 50;
                pesoLibro = pesoHojasEst + pesoTapaDura;
                return pesoLibro;
            } else {
                int pesoTapaBlanda = 20;
                pesoLibro = pesoHojasEst + pesoTapaBlanda;
                return pesoLibro;
            }

        }


    }

    public String toString(int pesoLibro) {
        return "Libro{" +
                "nombre='" + nombre + '\'' +
                ", autor='" + autor + '\'' +
                ", peso='" + pesoLibro;
    }


}




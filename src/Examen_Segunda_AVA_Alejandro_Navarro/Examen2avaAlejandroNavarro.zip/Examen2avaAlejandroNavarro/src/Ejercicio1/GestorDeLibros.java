package Ejercicio1;

import java.util.ArrayList;
import java.util.ListResourceBundle;
import java.util.Scanner;

public class GestorDeLibros {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<Libro> listaLibros = new ArrayList<>();
        int opcion = 0;
        while (opcion != 5) {
            menu();
            try {
                opcion = scanner.nextInt();
                switch (opcion) {
                    case 1:
                        introducirLibro(listaLibros);
                        break;

                    case 2:
                        mostrarInformacion(listaLibros);
                        break;

                    case 3:
                        modificarGenero(listaLibros);
                        break;

                    case 4:
                        buscarLibrosAutor();
                        break;

                    case 5:
                        System.out.println("Saliendo...");
                        break;

                    default:
                        System.out.println("Opción incorrecta, inserta otro número");
                }
            } catch (IndexOutOfBoundsException e) {
                System.out.println("ERROR: " + e.getMessage());
                scanner.next();
            }

        }
        scanner.close();
    }

    public static void menu() {
        System.out.println("-- MENU --");
        System.out.println("1. Introducir libro");
        System.out.println("2. Mostrar información de un libro (por ISBN)");
        System.out.println("3. Modificar el género de un libro (por ISBN)");
        System.out.println("4. Buscar todos los libros de un autor");
        System.out.println("5. Salir");
    }

    public static void introducirLibro(ArrayList<Libro> listaLibros) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("----------------------------------------------");
        System.out.println("ENTRASTE A  'INTRODUCIR LIBRO':");
        try {
            System.out.println("Introduce el ISBN del libro: ");
            String isbn = scanner.nextLine();
            System.out.println("Introduce el nombre del libro ");
            String nombreLibro = scanner.next();
            System.out.println("Introduce el autor del libro: ");
            scanner.next();
            String autor = scanner.nextLine();
            System.out.println("Inttroduce el número de páginas del libro: ");
            int numPaginas = scanner.nextInt();
            System.out.println("Introduce el género del libro: ");
            scanner.next();
            String genero = scanner.nextLine();
            System.out.println("Introduce el formato del libro (tapaDura, tapaBlanda, deBolsillo): ");
            Estilo formato = Estilo.valueOf(scanner.next());
            if (formato.equals("TapaDura")) {
                listaLibros.add(new Libro(isbn, nombreLibro, autor, numPaginas, genero, formato));
            } else if (formato.equals("TapaBlanda")) {
                listaLibros.add(new Libro(isbn, nombreLibro, autor, numPaginas, genero, formato));
            } else if (formato.equals("DeBolsillo")) {
                listaLibros.add(new Libro(isbn, nombreLibro, autor, numPaginas, genero, formato));
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

    }

    public static void mostrarInformacion(ArrayList<Libro> listaLibros) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("-------------------");
        System.out.println("Entraste a 'Mostrar Informacion de un libro (por ISBN)");
        System.out.println("Introduce el ISBN del libro: ");
        String isbnUsu = scanner.nextLine();
        if (listaLibros.isEmpty()) {
            System.out.println("No hay libros");
        } else if (listaLibros.contains(isbnUsu)) {
            System.out.println(listaLibros);
        }
    }

    public static void modificarGenero(ArrayList<Libro> listaLibros) {
        try {
            System.out.println("---------------");
            Scanner scanner = new Scanner(System.in);
            System.out.println("Entraste a 'Modificar género (por ISBN): ");
            System.out.println("Introduce el isbn del libro que quieres modificar el género: ");
            String isbnUsu = scanner.nextLine();
            System.out.println("Introduce que género quieres ponerle a este libro: ");
            String generoUsu = scanner.nextLine();
            //Libro.setLibro = generoUsu;
            System.out.println(listaLibros);
        }catch (IndexOutOfBoundsException e){
            System.out.println("ERROR");
            System.out.println(e.getMessage());
        }
    }

    public static void buscarLibrosAutor() {

    }
}

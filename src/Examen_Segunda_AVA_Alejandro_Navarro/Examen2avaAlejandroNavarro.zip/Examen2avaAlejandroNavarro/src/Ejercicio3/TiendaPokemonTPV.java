package Ejercicio3;

import org.w3c.dom.ls.LSOutput;

import java.util.ArrayList;
import java.util.Scanner;

public class TiendaPokemonTPV {
    public static void main(String[] args) {
        ArrayList<Integer> ticket = new ArrayList<>();
        Scanner scanner = new Scanner(System.in);
        int opcion = 0;
        while (opcion != 7) {
            menu();
            opcion = scanner.nextInt();
            try {
                switch (opcion) {
                    case 1:
                        anadirPocion(ticket);
                        break;

                    case 2:
                        anadirPokeball(ticket);
                        break;

                    case 3:
                        anadirAccesorio(ticket);
                        break;

                    case 4:
                        borrarArticulo(ticket);
                        break;

                    case 5:
                        mostrarArticulos(ticket);
                        break;

                    case 6:
                        mostrarTotal(ticket);
                        break;

                    case 7:
                        System.out.println("Saliendo");
                        break;
                }
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }finally {
                System.out.println("Cerrando programa...");
            }
        }
        scanner.close();
    }

    public static void menu() {
        System.out.println("1. Añadir pocion al ticket.");
        System.out.println("2. Añadir pokébola al ticket.");
        System.out.println("3. Añadir accesorio al ticket.");
        System.out.println("4. Borrar el artículo del ticket.");
        System.out.println("5. Mostrar todos los artículos del ticket.");
        System.out.println("6. Mostrar total.");
        System.out.println("7. Salir.");
        System.out.println("");
        System.out.println("Introduce la opción que quieras: ");
    }

    public static void anadirPocion(ArrayList ticket) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Introduce el nivel de la poción que quieres comprar: ");
        int nivelPocion = scanner.nextInt();
        int precioPocion = nivelPocion * 5;
        ticket.add(precioPocion);
        scanner.close();
    }

    public static void anadirPokeball(ArrayList ticket) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Dime el tipo de Pokeball que es: (Pokeball, GreatBall, UltraBall): ");
        tipoPokeball tipoUsu = tipoPokeball.valueOf(scanner.next());
        if (tipoUsu == tipoPokeball.Pokeball) {
            ticket.add(2);
        } else if (tipoUsu == tipoPokeball.GreatBall) {
            ticket.add(5);
        } else {
            ticket.add(10);
        }
        scanner.close();

    }

    public static void anadirAccesorio(ArrayList ticket) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Precio del accesorio introducido al ticket correctamente: ");
        ticket.add(7);
        scanner.close();
    }

    public static void borrarArticulo(ArrayList ticket){
        Scanner scanner = new Scanner(System.in);
        System.out.println("Articulo borrado con exito");
        ticket.remove(ticket.size() - 1);
        scanner.close();
    }

    public static void mostrarArticulos(ArrayList ticket){
        System.out.println(ticket);
    }

    public static void mostrarTotal(ArrayList ticket){
        System.out.println(ticket);
    }

}

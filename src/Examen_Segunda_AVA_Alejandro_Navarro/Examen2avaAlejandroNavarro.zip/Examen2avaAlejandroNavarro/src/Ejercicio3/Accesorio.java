package Ejercicio3;

public class Accesorio {
    public String nombre;
    public int precio = 7;

    public Accesorio(String nombre, int precio) {
        this.nombre = nombre;
        this.precio = precio;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getPrecio() {
        return precio;
    }

    public void setPrecio(int precio) {
        this.precio = precio;
    }

    @Override
    public String toString() {
        return "Accesorio{" +
                "nombre='" + nombre + '\'' +
                ", precio=" + precio +
                '}';
    }
}

package Ejercicio3;

enum tipoArticulo {
    pocion, pokeball, accesorio
}

public abstract class Articulo {
    public String nombre;
    public boolean gratis;
    public tipoArticulo tipo;


    public Articulo(String nombre, boolean gratis, tipoArticulo tipo) {
        this.nombre = nombre;
        this.gratis = gratis;
        this.tipo = tipo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public boolean isGratis() {
        return gratis;
    }

    public void setGratis(boolean gratis) {
        this.gratis = gratis;
    }

    public tipoArticulo getTipo() {
        return tipo;
    }

    public void setTipo(tipoArticulo tipo) {
        this.tipo = tipo;
    }

    @Override
    public String toString() {
        return "Articulo{" +
                "nombre='" + nombre + '\'' +
                ", gratis=" + gratis +
                ", tipo=" + tipo +
                '}';
    }
}

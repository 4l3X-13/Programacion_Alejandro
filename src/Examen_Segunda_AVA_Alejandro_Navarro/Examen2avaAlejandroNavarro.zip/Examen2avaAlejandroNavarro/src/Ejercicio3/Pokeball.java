package Ejercicio3;

enum tipoPokeball {
    Pokeball, GreatBall, UltraBall
}

public class Pokeball {
    public Pokeball tipo;
    public int precioPokeball = 2;
    public int precioGreatBall = 5;
    public int precioUltraBall = 10;


    public Pokeball(Pokeball tipo, int precioPokeball, int precioGreatBall, int precioUltraBall) {
        this.tipo = tipo;
        this.precioPokeball = precioPokeball;
        this.precioGreatBall = precioGreatBall;
        this.precioUltraBall = precioUltraBall;
    }

    public Pokeball getTipo() {
        return tipo;
    }

    public void setTipo(Pokeball tipo) {
        this.tipo = tipo;
    }

    public int getPrecioPokeball() {
        return precioPokeball;
    }

    public void setPrecioPokeball(int precioPokeball) {
        this.precioPokeball = precioPokeball;
    }

    public int getPrecioGreatBall() {
        return precioGreatBall;
    }

    public void setPrecioGreatBall(int precioGreatBall) {
        this.precioGreatBall = precioGreatBall;
    }

    public int getPrecioUltraBall() {
        return precioUltraBall;
    }

    public void setPrecioUltraBall(int precioUltraBall) {
        this.precioUltraBall = precioUltraBall;
    }

    @Override
    public String toString() {
        return "Pokeball{" +
                "tipo=" + tipo +
                ", precioPokeball=" + precioPokeball +
                ", precioGreatBall=" + precioGreatBall +
                ", precioUltraBall=" + precioUltraBall +
                '}';
    }
}

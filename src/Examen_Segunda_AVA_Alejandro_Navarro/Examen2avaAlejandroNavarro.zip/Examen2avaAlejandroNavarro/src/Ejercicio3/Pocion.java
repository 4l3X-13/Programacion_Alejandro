package Ejercicio3;

import java.util.ArrayList;

public class Pocion {
    public int nivel;
    ArrayList<String> efectos = new ArrayList<>();
    public int precio;

    public Pocion(int nivel, ArrayList<String> efectos, int precio) {
        this.nivel = nivel;
        this.efectos = efectos;
        this.precio = precio;
    }

    public int getNivel() {
        return nivel;
    }

    public void setNivel(int nivel) {
        this.nivel = nivel;
    }

    public int getPrecio() {
        return precio = 5;
    }

    public void setPrecio(int precio) {
        this.precio = precio * nivel;
    }

    public ArrayList<String> getEfectos() {
        return efectos;
    }

    public void setEfectos(ArrayList<String> efectos) {
        this.efectos = efectos;
    }

    @Override
    public String toString() {
        return "Pocion{" +
                "nivel=" + nivel +
                ", efectos=" + efectos +
                ", precio=" + precio +
                '}';
    }
}

package Ejercicio2;

public class Billete implements Dinero {
    public int valor;


    @Override
    public void valor() {
        System.out.println(valor);
    }

    public Billete(int valor) {
        this.valor = valor;
    }

    public int getValor() {
        return valor;
    }

    public void setValor(int valor) {
        this.valor = valor;
    }
}

package Ejercicio2;

interface Dinero {
    void valor();
}
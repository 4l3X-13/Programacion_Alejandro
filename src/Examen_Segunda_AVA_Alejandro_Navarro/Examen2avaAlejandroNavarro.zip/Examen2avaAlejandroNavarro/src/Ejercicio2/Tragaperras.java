package Ejercicio2;

public class Tragaperras {
    public static void main(String[] args) {
    //Cartera.cartera.add(Billete,Tarjeta)
    }
}

package Ejercicio2;

public class Tarjeta implements Dinero {
        public String numero;
        public double saldo;
        public double credito;


    @Override
    public void valor() {
        System.out.println(saldo + credito);
    }

    public Tarjeta(String numero, double saldo, double credito) {
        this.numero = numero;
        this.saldo = saldo;
        this.credito = credito;
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public double getCredito() {
        return credito;
    }

    public void setCredito(double credito) {
        this.credito = credito;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }
}

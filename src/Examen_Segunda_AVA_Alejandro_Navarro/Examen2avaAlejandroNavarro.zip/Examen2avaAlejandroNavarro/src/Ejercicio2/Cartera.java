package Ejercicio2;

import java.util.ArrayList;

public class Cartera {
    static ArrayList<Dinero> cartera = new ArrayList<>();

}
